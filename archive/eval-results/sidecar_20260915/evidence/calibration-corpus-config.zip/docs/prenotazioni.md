# Prenotazioni degli eventi

## Posti disponibili
La VarianteA consente la prenotazione di un evento solo quando sono disponibili posti. Ogni prenotazione registra identificativo evento, partecipante e numero di posti. La conferma riduce la disponibilità dei posti dello stesso numero.

## Cancellazione
La cancellazione di una prenotazione restituisce i posti all'evento e invia una notifica al partecipante. La prenotazione cancellata resta nello storico con il suo stato aggiornato.

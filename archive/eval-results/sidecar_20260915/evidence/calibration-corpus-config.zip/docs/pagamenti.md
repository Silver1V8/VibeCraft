# Pagamenti degli eventi

## Conferma del pagamento
Un pagamento confermato contiene importo, valuta e identificativo della prenotazione. La ricevuta riporta la data del pagamento e il numero dei posti acquistati. Un pagamento rifiutato lascia la prenotazione in attesa.

## Rimborso
Il rimborso di una prenotazione cancellata registra un movimento distinto collegato al pagamento originale. Le operazioni vengono conservate nello storico.

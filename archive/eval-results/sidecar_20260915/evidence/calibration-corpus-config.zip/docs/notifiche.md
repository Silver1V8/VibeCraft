# Notifiche ai partecipanti

## Invio della conferma
Quando la prenotazione di un evento viene confermata, il partecipante riceve una notifica con data, luogo e numero di posti prenotati. Un identificativo impedisce l'invio duplicato della stessa notifica.

## Modifiche dell'evento
Una variazione di luogo o orario produce una notifica per ogni partecipante con prenotazione confermata. La consegna e gli errori sono registrati separatamente.

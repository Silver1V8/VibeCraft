def reserve_seats(available: int, requested: int) -> int:
    """Prenota posti per un evento e restituisce i posti disponibili."""
    if requested <= 0 or requested > available:
        raise ValueError("Numero di posti non disponibile")
    return available - requested
